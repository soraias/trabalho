<!DOCTYPE html>
<html lang="en">
    <head>
        <title></title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="estilo.css" rel="stylesheet">
    </head>
    <body>
        <form method="post" action="verifica.php">
            Login: <input type="text" name="login"><br>
            Senha: <input type="password" name="senha"><br>
            <input type="submit" name="botao" value="Entrar">
            </form>
    </body>
</html>